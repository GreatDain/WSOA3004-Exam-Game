Abreham Beta

Requires mouse to play.

Controls can be found in game.

Bugs:

Bugs with floating rocks around perimeter of playe area.

Enemy line of sight and audio range is a big short which therefore makes the game a bit easy.

Some collisions push player causing sliding for unknown reasons.

Enemy and player audio not fully working.

Road and car models missing.