﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class RollingText : MonoBehaviour
{
    public float letterDelay = 0.35f;

    //string myText;
    public int count = 0;

    public Text text1;
    public Text text2;
    public Text text3;
    public Text text4;
    public Text text5;
    public Text text6;
    public Text text7;

    public GameObject pick1;
    public GameObject pick2;

    public GameObject thomas1;
    public GameObject thomas2;
    public GameObject man1;
    public GameObject man2;

    string message = "";
    // Start is called before the first frame update
    void Start()
    {
        text1.enabled = false;
        text2.enabled = false;
        text3.enabled = false;
        text4.enabled = false;
        text5.enabled = false;
        text6.enabled = false;
        text7.enabled = false;

        thomas1.SetActive(false);
        thomas2.SetActive(false);
        man1.SetActive(false);
        man2.SetActive(false);

        pick1.SetActive(false);
        pick2.SetActive(false);
        //myText.text = message;
        //message = text1.text;
        //text1.text = "";
        //myText.text = "";
        //StartCoroutine(TypeText());
    }

    IEnumerator TypeText()
    {
        foreach (char letter in message.ToCharArray())
        {
            text1.text += letter;
            yield return new WaitForSeconds(letterDelay);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            StopAllCoroutines();
            dialogueCheck();
            count++;
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene(0);
        }

        /*if (Input.GetMouseButtonDown(1))
        {
            StopAllCoroutines();
            count--;
            dialogueCheck();
        }*/
    }

    void dialogueCheck()
    {
        if (count <= 0)
            count = 0;

        if (count == 0)
        {
            text1.enabled = true;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
        else if (count == 1)
        {
            text1.text = "";
            text1.text = text2.text;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
        else if (count == 2)
        {
            text1.text = "";
            text1.text = text3.text;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
        else if (count == 3)
        {
            text1.text = "";
            text1.text = text4.text;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
        else if (count == 4)
        {
            thomas1.SetActive(true);
            text1.text = "";
            text1.text = text5.text;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
        else if(count == 5)
        {
            thomas1.SetActive(false);
            thomas2.SetActive(true);
        }
        else if (count == 6)
        {
            man1.SetActive(true);
            text1.text = "";
            text1.text = text6.text;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
        else if (count == 7)
        {
            pick1.SetActive(true);
            pick2.SetActive(true);
            text1.text = "";
            text1.text = text7.text;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
    }

    public void pickThomas()
    {
        SceneManager.LoadScene(2);
    }

    public void pickOldMan()
    {
        SceneManager.LoadScene(3);
    }
}
