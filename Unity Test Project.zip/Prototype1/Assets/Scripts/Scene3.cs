﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Scene3 : MonoBehaviour
{
    public float letterDelay = 0.35f;
    public int count = 0;
    string message = "";

    public Text text1;
    public Text text2;
    public Text text3;
    public Text text4;
    public Text text5;
    public Text text6;

    public GameObject pick1;
    public GameObject pick2;
    public GameObject background;
    public GameObject background2;
    public GameObject gem;
    public GameObject gem2;
    public GameObject dragon;
    public GameObject dragon2;
    public GameObject gold;
    public GameObject oldman;
    public GameObject oldman2;
    public GameObject pontso;
    public GameObject pontso2;
    // Start is called before the first frame update
    void Start()
    {
        text1.enabled = false;
        text2.enabled = false;
        text3.enabled = false;
        text4.enabled = false;
        text5.enabled = false;
        text6.enabled = false;

        pick1.SetActive(false);
        pick2.SetActive(false);
        dragon.SetActive(false);
        dragon2.SetActive(false);
        gem.SetActive(false);
        gem2.SetActive(false);
        background2.SetActive(false);
        gold.SetActive(false);
        oldman2.SetActive(false);
        pontso2.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            StopAllCoroutines();
            dialogueCheck();
            count++;
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene(0);
        }
    }

    IEnumerator TypeText()
    {
        foreach (char letter in message.ToCharArray())
        {
            text1.text += letter;
            yield return new WaitForSeconds(letterDelay);
        }
    }

    void dialogueCheck()
    {
        if (count <= 0)
            count = 0;

        if (count == 0)
        {
            text1.enabled = true;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
        else if (count == 1)
        {
            dragon.SetActive(true);
        }
        else if (count == 2)
        {
            text1.text = "";
            text1.text = text2.text;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
        else if (count == 3)
        {
            gem.SetActive(true);
        }
        else if (count == 4)
        {
            pick1.SetActive(true);
            pick2.SetActive(true);
        }
        else if (count == 6)
        {
            text1.text = "";
            text1.text = text5.text;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
        else if (count == 7)
        {
            text1.text = "";
            text1.text = text6.text;
            message = text1.text;
            text1.text = "";
            StartCoroutine(TypeText());
        }
    }

    public void pickOldMan()
    {
        dragon.SetActive(false);
        dragon2.SetActive(true);
        pick1.SetActive(false);
        pick2.SetActive(false);
        gem.SetActive(false);
        gem2.SetActive(true);
        background.SetActive(false);
        background2.SetActive(true);
        text1.text = "";
        text1.text = text4.text;
        message = text1.text;
        text1.text = "";
        StartCoroutine(TypeText());
    }

    public void pickGem()
    {
        pick1.SetActive(false);
        pick2.SetActive(false);
        oldman.SetActive(false);
        oldman2.SetActive(true);
        gem2.SetActive(true);
        gem.SetActive(false);
        pontso.SetActive(false);
        pontso2.SetActive(true);
        background.SetActive(false);
        background2.SetActive(true);
        text1.text = "";
        text1.text = text3.text;
        message = text1.text;
        text1.text = "";
        StartCoroutine(TypeText());
        count = 8;
    }
}
